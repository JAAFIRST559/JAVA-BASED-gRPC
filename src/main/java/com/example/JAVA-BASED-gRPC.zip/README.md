# Java-Based gRPC Service for Device Data Processing

## Overview
This project implements a gRPC service for receiving device data.

## Setup Instructions
1. Install Java 8+ and Maven.
2. Clone the repository:
   ```sh
   git clone https://github.com/YOUR_USERNAME/grpc-device-data-service.git
   cd grpc-device-data-service
   ```
3. Compile and generate gRPC code:
   ```sh
   mvn clean install
   ```
4. Run the gRPC Server:
   ```sh
   mvn exec:java -Dexec.mainClass="com.example.grpc.GrpcServer"
   ```
5. Run the gRPC Client:
   ```sh
   mvn exec:java -Dexec.mainClass="com.example.grpc.GrpcClient"
   ```
